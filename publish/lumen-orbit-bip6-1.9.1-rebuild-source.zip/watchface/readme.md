# LUMEN ORBIT 1.9.1 — 再ビルド

## 成果物の返却・引き継ぎルール

このウォッチフェイスの成果物を返す際は、変更の有無にかかわらず、最終回答に
対応する最新版の次の3ファイルを、必ずこの順でまとめて提示してください。

1. `lumen-orbit-bip6-<version>.zpk`：最適化済みの端末向けパッケージ。
2. `lumen-orbit-bip6-<version>-rebuild-source.zip`：再ビルドに必要なソース・画像・設定・依存関係・手順。
3. `lumen-orbit-bip6-<version>-optimization.zip`：最適化に必要なスクリプト・依存関係・実行手順。

3ファイルは同じリリースに対応させてください。source ZIPと最適化用ZIPは分離し、
不要な照合結果・作業記録は含めません。別セッションでもこの3ファイルを使うため、
この返却ルールを両ZIPのREADMEに引き継いでください。

対象：Amazfit Bip 6。Node.js と npm、およびインターネット接続が必要です。
ビルドツールは package-lock.json で固定しています（Zeus CLI 1.9.3）。

## 手順

ZIPを展開し、watchface ディレクトリで実行します。

```sh
npm ci
node build.js build
```

成果物は dist ディレクトリの .zab ファイルです。
.zab はZIP形式で、その中の .zpk が端末向けパッケージです。

ビルド時にZeppの機種情報を取得します。取得に失敗した場合は、
ネットワークを確認してビルドを再実行してください。
